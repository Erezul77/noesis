# Noēsis Constitution

This is the ethical framework of the swarm.