# logic for syncing constitution
