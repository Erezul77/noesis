# persona archetype engine logic
