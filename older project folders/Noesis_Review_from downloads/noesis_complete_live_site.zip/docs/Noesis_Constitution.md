# Noēsis Constitution

This is the living ethical framework guiding all Noēsis nodes.